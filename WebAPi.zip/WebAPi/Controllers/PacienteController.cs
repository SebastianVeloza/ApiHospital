﻿using Microsoft.AspNetCore.Mvc;

namespace WebAPi.Controllers
{
	[ApiController]
	[Route("/Paciente")]
	public class PacienteController
	{
	}
}
