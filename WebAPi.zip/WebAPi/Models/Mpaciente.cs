﻿namespace WebAPi.NewFolder
{
	public class Mpaciente
	{
        public int idPaciente { get; set; }

		public string Nombre { get; set; }

        public int tipodoc { get; set; }
        public int docu { get; set; }
        public decimal tel { get; set; }

    }
}
